package battleship;
import java.util.Random;
public class Ocean {
	//Used to quickly determine which ship is in any given location
    private Ship[][] ships = new Ship[10][10];

    //The total number of shots fired by the user
    private int shotsFired;

    //The number of times a shot hit a ship. 
    //If the user shoots the same part of a ship more than once, every hit is counted, even though additional “hits” don’t do the user any good.
    private int hitCount;

    //The number of ships sunk (10 ships in all)
    private int shipsSunk;

    
    

    /**
     * Creates an ”empty” ocean
     * initializes any game variables, such as how many shots have been fired.
     */
    public Ocean(){

        for(int i=0;i<10;i++) {
        	for(int j=0;j<10;j++) {
        		this.ships[i][j]=new EmptySea();
        	}
        }
        this.shotsFired = 0;
        this.hitCount = 0;
        this.shipsSunk = 0;

    }

    /**
     * Place all ten ships randomly on the (initially empty) ocean. Place larger ships before smaller ones,
     */
    void placeAllShipsRandomly(){
    	Random random = new Random();
    	//place battleship
    	boolean horizontal = random.nextInt(2)==0?true:false;
    	int row = random.nextInt(10);
    	int column = random.nextInt(10);
    	Battleship battleship = new Battleship();
    	while(true) {
    		if(battleship.okToPlaceShipAt(row, column, horizontal, this)==true) {
        		battleship.placeShipAt(row, column, horizontal, this);
        		break;	
        	}
    		row = random.nextInt(10);
    		column = random.nextInt(10);
    	}
    	//place cruiser
    	for(int i = 2; i>0;i--) {
    		boolean horizontal1 = random.nextInt(2)==0?true:false;
        	int row1 = random.nextInt(10);
        	int column1 = random.nextInt(10);
        	Cruiser cruiser = new Cruiser();
        	while(true) {
        		if(cruiser.okToPlaceShipAt(row1, column1, horizontal1, this)==true) {
        			cruiser.placeShipAt(row1, column1, horizontal1, this);
        			break;
        		}
        		row1 = random.nextInt(10);
        		column1 = random.nextInt(10);	
        	}	
    	}
    	// place destroyer
    	for(int i = 3; i>0;i--) {
    		boolean horizontal2 = random.nextInt(2)==0?true:false;
        	int row2 = random.nextInt(10);
        	int column2 = random.nextInt(10);
        	Destroyer destroyer = new Destroyer();
        	while(true) {
        		if(destroyer.okToPlaceShipAt(row2, column2, horizontal2, this)==true) {
        			destroyer.placeShipAt(row2, column2, horizontal2, this);
        			break;
        		}
        		row2 = random.nextInt(10);
        		column2 = random.nextInt(10);	
        	}	
    	}
    	// place submarine
    	for(int i = 4; i>0;i--) {
    		boolean horizontal3 = random.nextInt(2)==0?true:false;
        	int row3 = random.nextInt(10);
        	int column3 = random.nextInt(10);
        	Submarine submarine = new Submarine();
        	while(true) {
        		if(submarine.okToPlaceShipAt(row3, column3, horizontal3, this)==true) {
        			submarine.placeShipAt(row3, column3, horizontal3, this);
        			break;
        		}
        		row3 = random.nextInt(10);
        		column3 = random.nextInt(10);	
        	}	
    	}	
    }

    /**
     * 
     * @param row
     * @param column
     * @return true if the given location contains a ship, false if it does not
     */
    boolean isOccupied(int row, int column){
    	//Delete two cases
    	if(this.getShipArray()[row][column].getShipType()!="empty") {
    		return true;
    	}else {
    		return false;	
    	}

        
    }
    

    /**
     * 
     * @return the number of shots fired (in the game)
     */
    int getShotsFired(){
        return this.shotsFired;
    }

    /**
     * @return the number of hits recorded (in the game). All hits are counted, not just the first time a given square is hit.
     */
    int getHitCount(){
        return this.hitCount;
    }

    /**
     * @return the number of ships sunk (in the game)
     */
    int getShipsSunk(){
        return this.shipsSunk;
    }

    /**
     * @return true if all ships have been sunk, otherwise false
     */
    boolean isGameOver(){
        int sink = this.getShipsSunk();
        if (sink ==10){
            return true;
        }else{
            return false;
        }
    }
    /**
     * Returns true if the given location contains a ”real” ship, still afloat,false if it does not. 
     * In addition, this method updates the number of shots that have been fired, and the number of hits.
     * @param row 
     * @param column
     * @return True if there is a ship
     */
    boolean shootAt(int row, int column) {
    	
    	Ship[][] ships = this.getShipArray();
    	boolean checkIsSunk = ships[row][column].isSunk();
        boolean checkShiphit = ships[row][column].shootAt(row, column);
        this.shotsFired += 1;
        if( checkShiphit && !checkIsSunk){
            this.hitCount += 1;
            boolean checkIsSunkTheLastPartOfShip = ships[row][column].isSunk();
            if(checkIsSunkTheLastPartOfShip==true) {
            	this.shipsSunk++;
            }
            return true;
        }else{
            return false;
        }
    	
    	/*
    	this.shotsFired++;
    	if(this.ships[row][column].isSunk()==false&&this.ships[row][column].getShipType()!="empty") {
    		this.ships[row][column].shootAt(row, column);
    		this.hitCount++;
    		return true;
    	}
    	if(this.ships[row][column].isSunk()==true) {
    		System.out.println("b");
    		this.shipsSunk++;
    		System.out.println(this.getShipsSunk());
    		return false;
    	}
    	//add
    	if(this.ships[row][column].getShipType()=="empty") {
    		this.ships[row][column].shootAt(row, column);
    		return false;
    	}
    	return false;
    	*/
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    }

    /**
     * 
     * @return the 10x10 array of Ships
     */
    Ship[][] getShipArray(){

        return this.ships;
    }

    /** 
     * Prints the Ocean.
     * The top left corner square should be 0, 0.
     * ‘x’: Use ‘x’ to indicate a location that you have fired upon and hit a (real) ship.
     * ‘-’: Use ‘-’ to indicate a location that you have fired upon and found nothing there.
     * Use ‘s’ to indicate a location containing a sunken ship.
     * ‘.’: and use ‘.’ (a period) to indicate a location that you have never fired upon.
     */
    void print(){
    	
    System.out.println("  0 1 2 3 4 5 6 7 8 9");
    
    for(int i = 0 ; i<= 9; i++){
        //TODO
        System.out.print(i + " ");
       for(int j = 0; j <= 9; j++){
    	   
    	    Ship ship = ships[i][j];
            String stringOfStatus = "? ";
            if(ship.getShipType() == "empty"){
                boolean checkHit = ship.getHit()[0];
                if(checkHit){
                    stringOfStatus = ship.toString();
                }else{
                    stringOfStatus = ". ";
                }
            }else{
                int bowColumn = ship.getBowColumn();
		        int bowRow = ship.getBowRow();
		        int position;
		        if(ship.isHorizontal()){
			        position = bowColumn - j;
		        }else{
			        position = bowRow - i;
		        }

		        if(ship.getHit()[position] == true){
                    stringOfStatus = ship.toString();
                }else{
                    stringOfStatus = ". ";
                }
            }
            System.out.print(stringOfStatus);
            if(j==9) System.out.print("\n");
    	    
    	   /*
            String stringOfStatus = "? ";
            if(this.ships[i][j].getShipType() == "empty"&&this.ships[i][j].getHit()[0]==true) {
            	stringOfStatus = this.ships[i][j].toString();
            }else if(this.ships[i][j].getShipType() == "empty"&&this.ships[i][j].getHit()[0]==false) {
            	stringOfStatus = ". ";
            }else if(this.ships[i][j].getShipType() != "empty"&&this.ships[i][j].notAllFalse()==true) {
            	stringOfStatus = this.ships[i][j].toString();
            }else if(this.ships[i][j].getShipType() != "empty"&&this.ships[i][j].notAllFalse()==false) {
            	stringOfStatus = ". ";
            }
            System.out.print(stringOfStatus);
            if(j==9) {
            	System.out.print("\n");	
            }
        }*/
    }

    	
    	
           
                

        
        
    
        
    }

}
}

